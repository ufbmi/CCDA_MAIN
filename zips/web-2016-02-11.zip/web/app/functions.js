function is_array(variable) {
	return variable instanceof Array
}
